package com.rnb2.diff.core;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileFilter;

/**
 * 
 * @author budukh
 *
 */
public class MainFrame extends JFrame {
	private static final String DEFAULT_DIR = "C:\\";

	private static final long serialVersionUID = 1L;

	private static final String C_TOOLS_DIFF_TOOL_DIFFER_1_0_SNAPSHOT_JAR = "\"c:\\Tools\\Diff_tool\\differ-1.0-SNAPSHOT.jar\"";
	private static final Color titleColor = new Color(139, 26, 26);
	private static final String PATH_SRC = "/com/rnb2/diff/";

	private static final String PROP_PATH_DB1  = "prop_path_db1";
	private static final String PROP_PATH_TOOL = "prop_path_tool";
	private static final String PROP_PATH_DB2  = "prop_path_db2";
	private static final String PROP_PATH_LOG  = "prop_path_log";
	private static final String PROP_FILENAME  = "Main.properties";
	
	private final ImageIcon ICON_EXIT = new ImageIcon(getClass().getResource(PATH_SRC + "img/exit.png"));
	private final ImageIcon ICON_GO = new ImageIcon(getClass().getResource(PATH_SRC + "img/go.png"));
	private final ImageIcon ICON_SETTING = new ImageIcon(getClass().getResource(PATH_SRC + "img/setting.png"));

	public Toolkit toolkit = Toolkit.getDefaultToolkit();
	private Dimension dimension = toolkit.getScreenSize();
	private int srcWidth = dimension.width - 800;
	private int srcHeight = dimension.height - 800;
	private Container container = getContentPane();
	private Map<String, JTextField> map = new HashMap<>();
	private JFileChooser chooserNds = new JFileChooser();
	private JFileChooser chooserDir = new JFileChooser();
	private JTextField fieldLog;
	private JToolBar toolbar = new JToolBar();

	private JButton button1 = new JButton("...");
	private JButton button2 = new JButton("...");
	private JButton button3 = new JButton("...");

	private String customDiffToolPath = C_TOOLS_DIFF_TOOL_DIFFER_1_0_SNAPSHOT_JAR;
	private Properties properties = new Properties();
	
	public MainFrame() {
		setTitle("Gui for diff tool \"differ-1.0-SNAPSHOT.jar\"");
		setSize(srcWidth, srcHeight);
		setLocationRelativeTo(null);
		Locale.setDefault(new Locale("ru","RU"));
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
						
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");//com.jgoodies.looks.plastic.Plastic3DLookAndFeel//"com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");//
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		final String fileName = getFileNameProperties();
		loadParameters(fileName);
		
		initFilechooser();
		initDirChooser();
		
		JPanel panelMain= new JPanel(new GridLayout(4, 1));
		
		button1.addActionListener(listenerPath1());
		button2.addActionListener(listenerPath2());
		button3.addActionListener(listenerPath3());
		
		fieldLog = new JTextField("summary_log");
		
		panelMain.add(getBoxPanel("Тестируемая база 1:", button1, "txt1"));
		panelMain.add(getBoxPanel("Тестируемая база 2:", button2, "txt2"));
		panelMain.add(getBoxPanel("Лог:", button3, "txt3", fieldLog));
		
		toolbar.setFloatable(false);
		toolbar.add(actionExit);
		toolbar.add(actionGo);
		toolbar.add(actionSetting);
		
		container.add(toolbar, BorderLayout.NORTH);
		container.add(panelMain, BorderLayout.CENTER);

		addWindowListener(windowCloseAdapter(fileName));
	}


	private String getFileNameProperties() {
		return new StringBuilder()
				.append(System.getProperties().get("user.home"))
				.append(System.getProperties().get("file.separator"))
				.append(PROP_FILENAME)
				.toString();
	}


	private void initFilechooser() {
		final NdsFilter filter = new NdsFilter();
		filter.addExtentions("nds");
		filter.setDescription("NDS Files");
		chooserNds.setFileFilter(filter);
	}
	
	private void initDirChooser() {
		//chooserDir.setCurrentDirectory(new File(System.getProperty("user.home")));
		chooserDir.setCurrentDirectory(new File(DEFAULT_DIR));
		chooserDir.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		chooserDir.setAcceptAllFileFilterUsed(false);
	}

	private ActionListener listenerPath1() {
		return new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				chooserNds.setCurrentDirectory(new File(DEFAULT_DIR));
				
				String property = properties.getProperty(PROP_PATH_DB1);
				if(property != null && property.isEmpty())
					chooserNds.setCurrentDirectory(new File(property));	
				
				int r = chooserNds.showOpenDialog(MainFrame.this);
				
				if(r == JFileChooser.APPROVE_OPTION){
					String string = chooserNds.getSelectedFile().getPath();
					JTextField jTextField1 = map.get("txt1");
					jTextField1.setText(string);
					
				}
			}
		};
	}
	Action actionSetting = new AbstractAction("", ICON_SETTING) {
		private static final long serialVersionUID = 1L;
		@Override
		public void actionPerformed(ActionEvent e) {
			String dialog = JOptionPane.showInputDialog("Path:", customDiffToolPath);
			if(dialog != null && !dialog.isEmpty()) {
				System.out.println(dialog);
				customDiffToolPath = dialog;
			}
		}
	};
	
	Action actionGo = new AbstractAction("", ICON_GO) {
		private static final long serialVersionUID = 1L;
		
		public void actionPerformed(ActionEvent e) {
			boolean error = false;
			for (Entry<String, JTextField> jTextField : map.entrySet()) {
				if (jTextField.getValue().getText().isEmpty()) {
					JOptionPane.showMessageDialog(rootPane, "Field with key = " + jTextField.getKey() + " is empty", "Error",
							JOptionPane.ERROR_MESSAGE);
					error = true;
					break;
				}
			}
			if (error) {
				return;
			}
			if (fieldLog.getText().isEmpty()) {
				JOptionPane.showMessageDialog(rootPane, " Log file name is empty", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			
			saveParameters(getFileNameProperties());
			
			String path1 = map.get("txt1").getText();
			String path2 = map.get("txt2").getText();
			String path3 = map.get("txt3").getText();
						
			String pathLib = "java -jar " + C_TOOLS_DIFF_TOOL_DIFFER_1_0_SNAPSHOT_JAR + " -i \"";
			//java -jar "C:\tools\differ_2.5.2\differ-1.0-SNAPSHOT.jar" -i 
			//"C:\Working process\2018\November\20\not_deterministic\first\UR10202\ROOT.NDS" -j 
			//"C:\Working process\2018\November\20\not_deterministic\second\UR10202\ROOT.NDS" -o 
			//"C:\Working process\2018\November\20\diff\summary_10202.txt"
			
			final StringBuilder sb = new StringBuilder();
			sb.append(pathLib);
			sb.append(path1);
			sb.append("\" -j \"");
			sb.append(path2);
			sb.append("\" -o \"");
			sb.append(path3 + "\\");
			sb.append(fieldLog.getText() + ".txt");
							
			System.out.println(sb.toString());
			try {

				Process process = Runtime.getRuntime().exec(sb.toString());// "explorer" sb.toString() // java -jar
																			// diff.jar
				System.out.println("process=" + process);
				int exitVal = process.waitFor();

				System.out.println("exitVal=" + exitVal);
			} catch (IOException | InterruptedException e1) {
				e1.printStackTrace();
			}
			
		}
						
							
		/*
			ProcessBuilder builder = new ProcessBuilder(sb.toString());		    
			try {
				builder.directory(new File(System.getProperty("user.home")));
				builder.command("cmd.exe " + sb.toString());
				Process process = builder.start();
				//int waitFor = process.waitFor();				
    		 	// System.out.println("waitFor=" + waitFor);
				
			} catch (IOException  e1) {
				
				e1.printStackTrace();
			}
		}*/
		
	};
	
	Action actionExit = new AbstractAction("", ICON_EXIT) {
		private static final long serialVersionUID = 1L;
		public void actionPerformed(ActionEvent e) {
			 saveParameters(getFileNameProperties());
			 dispose();
             System.exit(0);
		}
	};
	
	private ActionListener listenerPath2() {
		return new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int r = chooserNds.showOpenDialog(MainFrame.this);
				
				if(r == JFileChooser.APPROVE_OPTION){
					String string = chooserNds.getSelectedFile().getPath();
					JTextField jTextField1 = map.get("txt2");
					jTextField1.setText(string);
				}
			}
		};
	}

	private ActionListener listenerPath3() {
		return new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int r = chooserDir.showOpenDialog(MainFrame.this);

				if (r == JFileChooser.APPROVE_OPTION) {
					String string = chooserDir.getSelectedFile() + "";
					JTextField jTextField1 = map.get("txt3");
					jTextField1.setText(string);
				}
			}
		};
	}
	
	private Box getBoxPanel(String caption, JButton button, String key) {
		Box mainLeftBox = Box.createVerticalBox();
		Box searchBox = Box.createVerticalBox();
		TitledBorder titledBorder = new TitledBorder(new EtchedBorder(), caption);
		titledBorder.setTitleColor(new Color(139, 26, 26));
		searchBox.setBorder(new CompoundBorder(titledBorder, new EmptyBorder(1, 5, 3, 5)));

		Box periodPanel = Box.createHorizontalBox();
		periodPanel.add(button);
		periodPanel.add(Box.createHorizontalStrut(5));
		JTextField textField = new JTextField();
		map.putIfAbsent(key, textField);
		textField.setEditable(false);
		setTextFieldValue(key);

		periodPanel.add(textField);
		searchBox.add(periodPanel);
		mainLeftBox.add(searchBox);

		return mainLeftBox;
	}
	
	private void setTextFieldValue(String key) {
		JTextField jTextField = map.get(key);
		String value = "";
		switch (key) {
		case "txt1":
			value = properties.getProperty(PROP_PATH_DB1);
			break;
		case "txt2":
			value = properties.getProperty(PROP_PATH_DB2);
			break;
		case "txt3":
			value = properties.getProperty(PROP_PATH_LOG);
			break;

		default:
			break;
		}
		jTextField.setText(value);
	}


	private Box getBoxPanel(String caption, JButton button, String key, JTextField field) {
		Box mainLeftBox = Box.createVerticalBox();
		Box searchBox = Box.createVerticalBox();
		TitledBorder titledBorder = new TitledBorder(new EtchedBorder(), caption);
		titledBorder.setTitleColor(new Color(139, 26, 26));
		searchBox.setBorder(new CompoundBorder(titledBorder, new EmptyBorder(1, 5, 3, 5)));

		Box periodPanel = Box.createHorizontalBox();
		periodPanel.add(button);
		periodPanel.add(Box.createHorizontalStrut(5));
		JTextField textField = new JTextField();
		textField.setEditable(false);

		periodPanel.add(textField);
		periodPanel.add(Box.createHorizontalStrut(3));
		periodPanel.add(field);
		searchBox.add(periodPanel);
		mainLeftBox.add(searchBox);

		map.putIfAbsent(key, textField);
		return mainLeftBox;
	}
	
	
	protected Box getTitleBox(String title, List<Component> components, boolean isCompoundBorder, int widthPanel,
			int heightPanel) {
		JLabel label = new JLabel(title);
		Box box = Box.createVerticalBox();

		if (isCompoundBorder) {
			TitledBorder titledBorder = new TitledBorder(new EtchedBorder(), title);
			titledBorder.setTitleColor(titleColor);
			box.setBorder(new CompoundBorder(titledBorder, new EmptyBorder(0, 0, 0, 0)));
		} else {
			box.add(label);
		}
		for (Component component : components) {
			box.add(component);
		}
		box.setMinimumSize(new Dimension(widthPanel, heightPanel));
		box.setPreferredSize(box.getMinimumSize());
		box.revalidate();
		return box;
	}
	
	private WindowAdapter windowCloseAdapter(final String fileName) {
		return new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				saveParameters(fileName);
			}
		};
	}
	
	private void loadParameters(final String fileName){
		File file = new File(fileName);
		
		/*if(file.exists()){
			log.info(file.getName() +" - old file was exist delete it!!!");
			file.delete();
		}*/	
		
		File path = file.getParentFile();
		if (!path.exists()){
			path.mkdirs();
		}
		try{
			FileInputStream propf = new FileInputStream(file);
			properties.load(propf);
			propf.close();
		}
		 catch(FileNotFoundException exception){
			 FileOutputStream out = null;
				try {
					out = new FileOutputStream(fileName);
					properties.put(PROP_PATH_TOOL, customDiffToolPath);
					properties.put(PROP_PATH_DB1, "");
					properties.put(PROP_PATH_DB2, "");
					properties.put(PROP_PATH_LOG, "");
					properties.store(out, "MainWindow");
					
				} catch (IOException e) {}
				finally{
					if (out != null){
						try { 
							out.flush(); 
							out.close(); 
						} catch(Exception exc){}
					} 
				}
		 }
		 catch(IOException exception){
		 }
	}
	
	private void saveParameters(final String fileName){
		try(FileOutputStream out = new FileOutputStream(fileName);){
			properties.put(PROP_PATH_TOOL, customDiffToolPath);
			properties.put(PROP_PATH_DB1, map.get("txt1").getText());
			properties.put(PROP_PATH_DB2, map.get("txt2").getText());
			properties.put(PROP_PATH_LOG, map.get("txt3").getText());
			properties.store(out, "MainWindow");
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	
	static class NdsFilter extends FileFilter {
		private ArrayList<String> list = new ArrayList<>();
		private String descrip = "";

		public void addExtentions(String newVal) {
			if (!newVal.startsWith(".")) {
				newVal = "." + newVal;
				list.add(newVal.toLowerCase());
			}
		}

		@Override
		public boolean accept(File f) {
			if (f.isDirectory())
				return true;
			String string = f.getName().toLowerCase();

			for (int i = 0; i < list.size(); i++) {
				if (string.endsWith((String) list.get(i)))
					return true;
			}

			return false;
		}

		@Override
		public String getDescription() {
			return descrip;
		}

		public String setDescription(String newval) {
			return descrip = newval;
		}
	}
}
